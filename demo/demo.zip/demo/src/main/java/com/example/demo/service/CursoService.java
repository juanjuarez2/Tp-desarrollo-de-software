package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.model.Curso;
import com.example.demo.repository.CursoRepository;

@Service
public class CursoService {
private final CursoRepository cursoRepository;
public CursoService (CursoRepository cursoRepository) {
	this.cursoRepository= cursoRepository;
}
public Curso saveCurso(Curso curso) {
    try {
        return cursoRepository.save(curso);
    } catch (Exception e) {
        // Handle exception or log the error
        throw new RuntimeException("Failed to save curso: " + e.getMessage());
    }
}// Get all cursos
public List<Curso> fetchAllCursos() {
    try {
        return cursoRepository.findAll();
    } catch (Exception e) {
        // Handle exception or log the error
        throw new RuntimeException("Failed to fetch all cursos: " + e.getMessage());
    }
}
//Get a curso by ID
public Optional<Curso> fetchCursoById(Long id) {
     try {
         return cursoRepository.findById(id);
     } catch (Exception e) {
         // Handle exception or log the error
         throw new RuntimeException("Failed to fetch curso by ID: " + e.getMessage());
     }
 }
public Optional<Curso> updateCurso(Long id, Curso updatedCurso) {
    try {
        Optional<Curso> existingCursoOptional = cursoRepository.findById(id);
        if (existingCursoOptional.isPresent()) {
            Curso existingCurso = existingCursoOptional.get();
            existingCurso.setFechaInicio(updatedCurso.getFechaInicio());
            existingCurso.setFechaFin(updatedCurso.getFechaFin());
            existingCurso.setTema(updatedCurso.getTema());
            existingCurso.setDocente(updatedCurso.getDocente());
            existingCurso.setAlumnos(updatedCurso.getAlumnos());
            Curso savedEntity = cursoRepository.save(existingCurso);
            return Optional.of(savedEntity);
        } else {
            return Optional.empty();
        }
    } catch (Exception e) {
        // Handle exception or log the error
        throw new RuntimeException("Failed to update curso: " + e.getMessage());
    }
}
public boolean deleteCurso(Long id) {
    try {
        cursoRepository.deleteById(id);
        return true; // Deletion successful
    } catch (Exception e) {
        // Handle exception or log the error
        throw new RuntimeException("Failed to delete curso: " + e.getMessage());
    }
}}