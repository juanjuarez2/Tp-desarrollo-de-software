package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Curso;
import com.example.demo.model.Curso;
import com.example.demo.service.CursoService;
import com.example.demo.service.CursoService;

@RestController
@RequestMapping("/api/v1")
public class CursoController {
private final CursoService cursoService;
public CursoController(CursoService cursoService) {
	this.cursoService= cursoService;
}
// Create a new curso
@PostMapping(value = "/curso")
public ResponseEntity<Curso> saveCurso(@RequestBody Curso curso) {
    // Verifica el valor del nombre antes de guardar
    Curso savedCurso = cursoService.saveCurso(curso);
    return ResponseEntity.ok(savedCurso);
}
// Get all cursos
@GetMapping("/cursos")
public ResponseEntity<List<Curso>> getAllCursos() {
    List<Curso> cursos = cursoService.fetchAllCursos();
    return ResponseEntity.ok(cursos);
}


// Get a curso by ID
@GetMapping("/curso/{id}")
public ResponseEntity<Curso> getCursoById(@PathVariable Long id) {
    Optional<Curso> cursoOptional = cursoService.fetchCursoById(id);
    return cursoOptional.map(ResponseEntity::ok)
            .orElseGet(() -> ResponseEntity.notFound().build());
}
@PutMapping(path = "/curso/{CursoId}")
public ResponseEntity<Curso> updateCurso(@PathVariable Long CursoId, @RequestBody Curso curso) {
    Optional<Curso> updatedCursoOptional = cursoService.updateCurso(CursoId, curso);
    return updatedCursoOptional.map(ResponseEntity::ok)
            .orElseGet(() -> ResponseEntity.notFound().build());
}
}
